import java.util.*;
import java.util.concurrent.*;

public class SymbolTable{

    LinkedHashMap<String, UserClasses> SymbolTable = new LinkedHashMap<String, UserClasses>();

    public void Insert(String name, UserClasses class_input){
        this.SymbolTable.put(name, class_input);
    }
    public void Print(GlobalVars global, Offsets ofs){
        for(Map.Entry<String,UserClasses> entry : this.SymbolTable.entrySet()){
            entry.getValue().Print(global, ofs);
        }
    }
    public boolean Search(String value){
        return this.SymbolTable.containsKey(value);
    }
    public UserClasses FindClass(String name){
        return this.SymbolTable.get(name);
    }
    public boolean ExistsClass(String name){
        return this.SymbolTable.containsKey(name);
    }
    public Method FindMethod(String classname){
        for(Map.Entry<String,UserClasses> entry : this.SymbolTable.entrySet()){
            if(entry.getValue().SearchMethod(classname))
                return entry.getValue().GetMethod(classname);
        }
        return null;
    }
    public UserClasses ClassByName(String classname){
        for(Map.Entry<String,UserClasses> entry : this.SymbolTable.entrySet()){
            if(entry.getValue().SearchMethod(classname))
                return entry.getValue();
        }
        return null;    
    }
    public void IterateVtables(){
        for(Map.Entry<String,UserClasses> entry : this.SymbolTable.entrySet()){
            System.out.println("@." + entry.getValue().GetName() + " = global [" + entry.getValue().GetSize() + " x i8*] [");
        }      
    }
}


