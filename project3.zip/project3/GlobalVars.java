public class GlobalVars{
    int fields_offset = 0;
    int methods_offset = 0;
}